/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wig180009l6q2;

/**
 *
 * @author Huei Ching
 */
public class Node<E> {
    E element;
    Node<E> next;

    public Node() {
    }

    public Node(E element) {
        this.element = element;
    }
}
