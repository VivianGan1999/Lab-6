/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wig180009l6q2;

/**
 *
 * @author Huei Ching
 */
public class MyLinkedList<E> {
    private Node<E> head;
    private Node<E> tail;
    private int size = 0;

    public MyLinkedList() {
    }
    
    public void add(E e){
        Node<E> newNode = new Node<>(e);
        if(head==null){
            head = tail = newNode;
        }
        else{
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }
    
    public void removeFirst(){
        head = head.next;
        if(head==null) tail = null;
        size--;
    }
    
    public void removeLast(){
        if(size==1){
            head = tail = null;
            size--;
        }
        else{
            Node<E> current = head;
            for(int i=1; i<size-1; i++){
                current = current.next;
            }
            tail = current;
            tail.next = null;
            size--;
        }
    }
    
    public void removeElement(E e){
        int index = 0;
        Node<E> current = head;
        for(int i=0; i<size; i++){
            if(current.element.equals(e)){
                index = i;
                break;
            }
            current = current.next;
        }
        current = head;
        if(index==0) removeFirst();
        else if(index==size-1) removeLast();
        else{
            for(int i=1; i<index; i++){
                current = current.next;
            }
            current.next = (current.next).next;
            size--;
        }
    }
    
    public void printList(){
        Node<E> current = head;
        for(int i=0; i<size; i++){
            if(i!=size-1) System.out.print(current.element+", ");
            else System.out.print(current.element+".");
            current = current.next;
        }
        System.out.println("");
    }

    public int getSize() {
        return size;
    }
    
    public boolean contains(E e){
        Node<E> current = head;
        for(int i=0; i<size; i++){
            if(current.element.equals(e)) return true;
            current = current.next;
        }
        return false;
    }
    
    public void replace(E e, E newE){
        Node<E> current = head;
        for(int i=0; i<size; i++){
            if(current.element.equals(e)){
                current.element = newE;
                break;
            }
            current = current.next;
        }
    }
}
