/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wig180009l6q2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Huei Ching
 */
public class WIG180009L6Q2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter your students name list. Enter 'n' to end......");
        MyLinkedList<String> nameList = new MyLinkedList<>();
        String input = "";
        while(!input.equalsIgnoreCase("n")){
            input = s.nextLine();
            if(!input.equalsIgnoreCase("n")) nameList.add(input);
        }
        System.out.println("\nYou have entered the following students' name :");
        nameList.printList();
        System.out.println("\nThe number of students entered is : "+nameList.getSize());
        System.out.println("\nAll the names entered are correct? Enter 'r' to rename the student name, 'n' to proceed.");
        String rename = s.nextLine();
        if(rename.equalsIgnoreCase("r")){
            System.out.println("\nEnter the existing student name that you want to rename : ");
            String nameOri = s.nextLine();
            System.out.println("\nEnter the new name : ");
            String nameNew = s.nextLine();
            nameList.replace(nameOri, nameNew);
            System.out.println("\nThe new student list is :");
            nameList.printList();
        }
        System.out.println("\nDo you want to remove any of your student name? Enter 'y' for yes, 'n' to proceed.");
        String remove = s.nextLine();
        if(remove.equalsIgnoreCase("y")){
            System.out.println("\nEnter a student name to remove : ");
            String nameToRemove = s.nextLine();
            nameList.removeElement(nameToRemove);
            System.out.println("\nThe number of updated student is :"+nameList.getSize());
            System.out.println("The updated students list is :");
            nameList.printList();
        }
        System.out.println("\nAll student data captured complete. Thank you!");
    }
    
}
