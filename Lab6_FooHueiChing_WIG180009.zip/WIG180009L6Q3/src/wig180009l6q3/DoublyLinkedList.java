/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wig180009l6q3;

/**
 *
 * @author Huei Ching
 */
public class DoublyLinkedList<E> {
    private Node<E> head;
    private Node<E> tail;
    private int size = 0;

    public DoublyLinkedList() {
    }
    
    public void addFirst(E element){
        Node<E> newNode = new Node<>(element,head,null);
        if(head != null) head.prev = newNode;
        head = newNode;
        if(tail==null) tail = newNode;
        size++;
        System.out.println("adding: "+element);
    }
    
    public void addLast(E element){
        Node<E> newNode = new Node<>(element,null,tail);
        if(tail != null) tail.next = newNode;
        tail = newNode;
        if(head == null) head = newNode;
        size++;
        System.out.println("adding: "+element);
    }
    
    public void add(int index, E element){
        if(index==0) addFirst(element);
        else if(index==size) addLast(element);
        else if(index<0 || index>size) throw new IndexOutOfBoundsException();
        else{
            Node<E> temp = head;
            for(int i=0; i<index; i++){
                temp = temp.next;
            }
            Node<E> newNode = new Node<>(element,temp,temp.prev);
            temp.prev.next = newNode;
            temp.prev = newNode;
            size++;
            //System.out.println("adding: "+element);
        }
    }
    
    public E removeFirst(){
        if(size==0) throw new IndexOutOfBoundsException();
        Node<E> temp = head;
        head = head.next;
        head.prev = null;
        size--;
        System.out.println("deleted: "+temp.element);
        return temp.element;
    }
    
    public E removeLast(){
        if(size==0) throw new IndexOutOfBoundsException();
        Node<E> temp = tail;
        tail = tail.prev;
        tail.next = null;
        size--;
        System.out.println("deleted: "+temp.element);
        return temp.element;
    }
    
    public E remove(int index){
        E temp = null;
        if(index<0 || index>=size) throw new IndexOutOfBoundsException();
        else if(index==0) removeFirst();
        else if(index==size-1) removeLast();
        else{
            Node<E> current = head;
            for(int i=0; i<index; i++){
                current = current.next;
            }
            temp = current.element;
            current.prev.next = current.next;
            current.next.prev = current.prev;
            current.next = current.prev = null;
            size--;
            System.out.println("deleted: "+temp);
        }
        return temp;
    }

    public int getSize() {
        return size;
    }
    
    public void clear(){
        int s = size;
        size = 0;
        Node<E> temp = head;
        while(head != null){
            temp = head.next;
            head.prev = head.next = null;
            head = temp;
        }
        temp = null;
        tail.prev = tail.next = null;
        System.out.println("successfully clear "+s+" node(s)");
    }
    
    public void iterateForward(){
        Node<E> current = head;
        for(int i=0; i<size; i++){
            System.out.print(current.element+" ");
            current = current.next;
        }
        System.out.println("");
    }
    
    public void iterateBackward(){
        Node<E> current = tail;
        for(int i=size-1; i>=0; i--){
            System.out.print(current.element+" ");
            current = current.prev;
        }
        System.out.println("");
    }
}
