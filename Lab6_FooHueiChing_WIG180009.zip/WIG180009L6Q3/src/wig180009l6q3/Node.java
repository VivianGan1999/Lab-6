/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wig180009l6q3;

/**
 *
 * @author Huei Ching
 */
public class Node<E> {
    E element;
    Node<E> next;
    Node<E> prev;

    public Node(E element) {
        this(element,null,null);
    }

    public Node(E element, Node<E> next, Node<E> prev) {
        this.element = element;
        this.next = next;
        this.prev = prev;
    }
    
    
}
