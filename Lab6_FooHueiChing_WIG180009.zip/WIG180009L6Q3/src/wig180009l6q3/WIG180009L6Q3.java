/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wig180009l6q3;

/**
 *
 * @author Huei Ching
 */
public class WIG180009L6Q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DoublyLinkedList<Integer> a = new DoublyLinkedList<>();
        a.addFirst(1);
        a.addLast(10);
        a.addLast(100);
        a.add(2,2);
        a.remove(3);
        System.out.println("\niterating forward..");
        a.iterateForward();
        System.out.println("iterating backward..");
        a.iterateBackward();
        System.out.println("size of current Doubly Linked List: "+a.getSize());
        a.clear();
        System.out.println("\nsize of current Doubly Linked List: "+a.getSize());
    }
    
}
